Chapter 9 Programs:

robotArm.html: simple arm model with a base, lower arm and upper arm using an explicit description in js file.

figure.js: figure model with head, arms and legs using a tree structured model and a generalized traversal.